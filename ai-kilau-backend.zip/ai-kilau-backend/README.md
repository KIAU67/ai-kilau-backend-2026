# AI KILAU Backend

Backend proxy supaya **API Key OpenRouter tersembunyi di server**.

Frontend / APK hanya memanggil:
```
POST https://URL-SERVER-KAMU/chat
```

---

## 1. Daftar Railway

1. Buka https://railway.app
2. Login dengan GitHub / Google
3. Klik **New Project**

---

## 2. Deploy dari folder ini

### Opsi A — Deploy lewat GitHub (disarankan)
1. Upload folder `ai-kilau-backend` ke repository GitHub
2. Di Railway: **New Project → Deploy from GitHub repo**
3. Pilih repo tersebut

### Opsi B — Deploy manual
1. Di Railway: **New Project → Empty Project**
2. **Add Service → GitHub Repo** atau upload kode
3. Root directory: folder yang berisi `server.js` + `package.json`

Railway akan otomatis jalanin:
```bash
npm install
npm start
```

---

## 3. Set Environment Variable (WAJIB)

Di Railway → project → service → **Variables**:

| Name | Value |
|------|--------|
| `OPENROUTER_API_KEY` | `sk-or-v1-...` (key dari openrouter.ai) |
| `DEFAULT_MODEL` | `openrouter/free` (opsional) |

**Jangan** taruh API Key di kode.

---

## 4. Ambil URL publik

Setelah deploy sukses:
1. Buka tab **Settings** → **Networking** / **Public Domain**
2. Generate domain, contoh:
   ```
   https://ai-kilau-production.up.railway.app
   ```
3. Tes di browser:
   ```
   https://URL-KAMU/
   ```
   Harus muncul JSON: `"ok": true`

---

## 5. Endpoint yang dipakai aplikasi

```
POST /chat
Content-Type: application/json

{
  "message": "Halo",
  "language": "Indonesia",
  "history": [],
  "model": "openrouter/free",
  "temperature": 0.7,
  "stream": true
}
```

Response: stream SSE (sama seperti OpenRouter) atau JSON `{ "reply": "..." }` jika stream=false.

---

## 6. Hubungkan ke AI KILAU (HTML/APK)

Di Settings aplikasi:
- **API Endpoint**: `https://URL-KAMU/chat`
- **API Key**: boleh dikosongkan / diisi teks apa saja (backend tidak pakai key dari client)
- **Model**: `openrouter/free`

Atau nanti kita update HTML supaya default langsung ke server kamu dan Settings API Key disembunyikan.

---

## Render.com (alternatif)

1. https://render.com → New → Web Service
2. Connect repo yang berisi folder ini
3. Build: `npm install`
4. Start: `npm start`
5. Environment: `OPENROUTER_API_KEY=...`
6. Ambil URL `.onrender.com`

---

## Keamanan singkat

- API Key hanya di Environment Variable server
- Jangan commit file `.env` ke GitHub
- Bisa ditambah rate limit / API secret sederhana nanti jika perlu
